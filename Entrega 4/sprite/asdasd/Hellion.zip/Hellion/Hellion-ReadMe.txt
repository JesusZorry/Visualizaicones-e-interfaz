Credit: Molly "Cougarmint" Willits
Created by hand using Photoshop Educational Edition 6.0.

Licences: CC-BY 3.0, CC-BY-SA 3.0.

Free Commercial Use: Yes
Free Personal Use: Yes

Included in this Pack:
Hellion.png (for any project)
Hellion_norings.png
Hellion_B.png (RPG Maker VX Ace Ready)

Donations: Not needed, but appreciated. Contact me if you'd like to make a donation.